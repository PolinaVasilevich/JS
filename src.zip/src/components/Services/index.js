import React from 'react';
import Line from '../Line';
import Button from '../Button';


import './styles.css';

class Services extends React.Component {
    render() {
        const {leftContent, rightContent} = this.props.items;
        return (
            <section className='flexContainer'>
                <div className='leftContent'>
                    <h2 className='sectionTitle'>{leftContent.title}</h2>
                    <Line/>
                    <p className='sectionSubTitle'>{leftContent.subTitle}</p>
                    <p className='sectionText'>{leftContent.text}</p>
                    <ul>
                        {
                            (leftContent.list).map((item, index) => {
                                return (
                                    <li key={index}>{item}</li>
                                )
                            })
                        }
                    </ul>
                </div>
                <div className='rightContent flexContainer'>
                    {
                        rightContent.map(item => {
                            return (
                                <div> 
                                    <h3>{item.title}</h3>
                                    <p>{item.text}</p>
                                    <button></button>
                                </div>
                            )
                        })
                    }
                </div>
            </section>
        )
    }
}

export default Services;