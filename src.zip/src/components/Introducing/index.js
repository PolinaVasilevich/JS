import React from 'react';

import Button from '../Button';
import './styles.css';

class Introducing extends React.Component {
    render() {
        const {title, subTitle, text, buttonLabel, backgroundImg, buttonIcon} = this.props.items;
        return(
            <section>
                <div className='content'>
                    <div>
                        <h2 className='sectionTitle'>{title}</h2>
                        <div className='line'></div>
                    </div>
                    <p className='sectionSubTitle'>{subTitle}</p>
                    <p className='sectionText'>{text}</p>
                    <Button buttonIcon={buttonIcon} buttonLabel={buttonLabel}/>
                </div>

            </section>
        )
    }
}

export default Introducing;