import React from 'react';
import {Line} from './styles';

class LineComponent extends React.Component {
    render() {
        return (
            <Line></Line>
        )
    }
}

export default LineComponent;