import React, {Component} from 'react';

import {Section, InputContainer, InputTaskName, ButtonAddTask, ButtonContainer, ListItem, List, ButtonCross, TaskContainer } from './styles';

class Form extends Component {
    constructor(props) {
        super(props);

        this.state = {
            tasks: [],
            value: '',
        }
    }

    handleChange = (e) => {
        this.setState({
            value: e.target.value,
        });
    }

    handleSubmit = (e) => {
        e.preventDefault();
        const taskArray = this.state.tasks;
        taskArray.push(this.state.value);
        this.setState ({tasks: taskArray}); 
    }


	deleteItem(index) {
		this.state.tasks.splice(index, 1);
		this.setState({tasks: this.state.tasks});
	}
    
    renderList() {
        const taskList = this.state.tasks;
        return (
            <List>
                {taskList.map((task, index) => 
                    <ListItem key={index}>
                        {task}
                        <ButtonCross onClick={this.deleteItem.bind(this, index)}>'Cross'
                        </ButtonCross>
                     </ListItem>)}
            </List>
        )
    }

    render() {
        return (
        <Section>
            <InputContainer>
                <InputTaskName type='text' placeholder='Task name' onChange={this.handleChange}/>
                <ButtonContainer>
                    <ButtonAddTask onClick={this.handleSubmit}>
                        <span>+</span>
                        Add task
                    </ButtonAddTask>
                </ButtonContainer>
            </InputContainer>

            <TaskContainer>
                {this.renderList()}
            </TaskContainer >
        </Section>
        )
    }
}

export default Form;