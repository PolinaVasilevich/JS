import React from 'react';
import './styles.css';
import Line from '../Line';

class Portfolio extends React.Component {
    render() {
        const {title, text, imgs} = this.props.items;
        return(
            <>
            <section>
                <div className='contentPortfolio'>
                    <h2 className='sectionTitle'>{title}</h2>
                    <Line/>
                    <p className='sectionText'>{text}</p>
                    <div className='imgContainer'>
                        {
                            imgs.map((img, index) => {
                                return (
                                    <div key = {index} className='img'>{img}</div>
                                )
                            })
                        }
                    </div>
                </div>
            </section>
            </>
        )
    }
}

export default Portfolio;