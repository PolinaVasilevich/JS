import React, {Component} from 'react';

class ListItem extends Component {
    
    render() {
        const textTask = this.props;
        return (
            <li>{textTask}</li>
        )
    }
}

export default ListItem;