import cubanese from "../img/partners/Logo 22@1X.png";
import handcraft from "../img/partners/IN NEW YORK@1X.png";
import premium from "../img/partners/Hover Logo@1X.png";
import genuine from "../img/partners/Genuine@1X.png";
import staton from "../img/partners/STATON@1X.png";
import southbeach from "../img/partners/Logo 8@1X.png";
import hord from "../img/partners/HAUS@1X.png";
import newyork from "../img/partners/LONG ISLAND MEN’S DIVISION@1X.png";

export default {
  title: "The Best Partners",
  text: "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor vive",
  list: [
    cubanese,
    handcraft,
    premium,
    genuine,
    staton,
    southbeach,
    hord,
    newyork,
  ],
};
