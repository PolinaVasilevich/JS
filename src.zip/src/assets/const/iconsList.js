export default [
    {
        title: 'Multiple Layouts',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-layout',
    },

    {
        title: 'Modern Designs',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-crown',
    },

    {
        title: 'Powerful Shopping',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-bag',
    },

    {
        title: 'Incredible Support',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-timer',
    },

    {
        title: 'Optimized for SEO',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-stats-up',
    },

    {
        title: 'Flexible Admin Options',
        text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.',
        icon: 'ti-panel',
    },


]

////http://thetheme.io/theadmin/content/icons-themify.html