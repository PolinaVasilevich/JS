export default [
    {
      icon: "ti-desktop",
      title: "100% Responsive",
      text:
        "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra.Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.",
    },
  
    {
      icon: "ti-settings",
      title: "Powerfull Admin",
      text:
        "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra.Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat. ",
    },
  
    {
      icon: "ti-ruler-pencil",
      title: "Incredible Design",
      text:
        "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra.Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.",
    },
  
    {
      icon: "ti-comment-alt",
      title: "The Best Support",
      text:
        "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra.Vehicula nibh vel ante commodo feugiat. Nulla ut enim lobortis orci gravida volutpat.",
    },
  ];