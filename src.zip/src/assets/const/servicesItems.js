export default 
{
    leftContent: {
        title: 'What We Do',
        subTitle: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Nulla vehicula nibh vel ante commodo feugiat.',
        text: 'TheFox include design that can be used for any type of website: business, corporate, portfolio, blog, products, magazine, etc. Buy TheFox and join our awesome community, let’s make TheFox better together!',
        list: [1, 2, 3, 4, 5, 6, 7, 8],
    },

    rightContent: [
        {
            icon: '',
            title:'Web Design',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },

        {
            icon: '',
            title:'Ecommerce',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },

        {
            icon: '',
            title:'Video Advertising',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },

        {
            icon: '',
            title:'Photography',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },

        {
            icon: '',
            title:'Graphic Design',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },

        {
            icon: '',
            title:'Support Tools',
            text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra',
        },
    ]
}