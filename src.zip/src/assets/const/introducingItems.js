export default {
  title: "Great Theme for Your Business",
  subTitle:
    "Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Nulla vehicula nibh vel ante commodo feugiat.",
  text:
    "Cras gravida arcu tincidunt, suscipit velit sed, porta sapien. Maecenas a aliquam lectus. Vivamus consequat purus quis ligula vestibulum, eget mattis ex fermentum. Donec placerat felis sit amet venenatis faucibus. Praesent aliquet convallis.",
  buttonLabel: "TAKE A TOUR",
  buttonIcon: "ti-light-bulb",
};
