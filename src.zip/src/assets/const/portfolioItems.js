export default 
{
    title: 'Selected Case Studies',
    text: 'Curabitur ac lacus arcu. Sed vehicula varius lectus auctor viverra. Nulla vehicula nibh vel ante commodo feugiat.',
    imgs: [1, 2, 3, 4, 5, 6, 7, 8],
}