import React from "react";

import Icons from "../../components/BlockWithIcons";
import Introducing from '../../components/Introducing';
import Portfolio from '../../components/Portfolio';
import BlockWithIconList from '../../components/BlockWithIconList';
import Services from '../../components/Services';

import iconsList from '../../assets/const/icons';
import introducingItems from '../../assets/const/introducingItems';
import portfolioItems from '../../assets/const/portfolioItems';
import iconsList2 from '../../assets/const/iconsList';
import servicesItems from '../../assets/const/servicesItems';

class Home extends React.Component {
  render() {
    return (
      <>
        <Icons items={iconsList} />
        <Introducing items = {introducingItems}/>
        <Portfolio items = {portfolioItems}/>
        <BlockWithIconList items = {iconsList2 }/>
        <Introducing items = {introducingItems} style={{float: 'right'}}/>
        <Services items={servicesItems}/>
      </>
 
    )

    
  }
}

export default Home;
